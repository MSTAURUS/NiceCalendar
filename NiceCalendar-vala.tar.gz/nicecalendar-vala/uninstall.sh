#!/usr/bin/env bash
# NiceCalendar (Vala) — per-user uninstall
set -euo pipefail

PREFIX="${HOME}/.local"

rm -f "${PREFIX}/lib/xfce4/panel/plugins/libnicecalendar.so"
rm -f "${PREFIX}/share/xfce4/panel/plugins/nicecalendar.desktop"
rm -rf "${PREFIX}/share/nicecalendar"
rm -f "${PREFIX}/share/icons/hicolor/scalable/apps/nicecalendar.svg"

# locales
find "${PREFIX}/share/locale" -name 'nicecalendar.mo' -delete 2>/dev/null || true

# xfconf keys for all plugin instances (best-effort)
if command -v xfconf-query >/dev/null 2>&1; then
  xfconf-query -c xfce4-panel -l 2>/dev/null \
    | grep -E '/plugins/plugin-[0-9]+/' \
    | while read -r prop; do
        # only remove if it looks like ours (heuristic: known keys)
        case "${prop}" in
          */show-date|*/show-time|*/date-format|*/time-format|*/first-day-of-week|*/show-adjacent-days)
            xfconf-query -c xfce4-panel -p "${prop}" -r 2>/dev/null || true
            ;;
        esac
      done || true
fi

if command -v gtk-update-icon-cache >/dev/null 2>&1; then
  gtk-update-icon-cache -f -t "${PREFIX}/share/icons/hicolor" 2>/dev/null || true
fi

echo "Uninstalled. Restart panel: xfce4-panel -r"
