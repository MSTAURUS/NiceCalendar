#!/usr/bin/env bash
# NiceCalendar (Vala) — per-user install
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
PREFIX="${HOME}/.local"
LIBDIR="${PREFIX}/lib/xfce4/panel/plugins"
DATADIR="${PREFIX}/share"
PLUGIN_DESKTOP_DIR="${DATADIR}/xfce4/panel/plugins"
UIDIR="${DATADIR}/nicecalendar/ui"
ICONDIR="${DATADIR}/icons/hicolor/scalable/apps"
LOCALEDIR="${DATADIR}/locale"

need() {
  command -v "$1" >/dev/null 2>&1 || {
    echo "Need: $1" >&2
    exit 1
  }
}

need meson
need ninja
need pkg-config
pkg-config --exists libxfce4panel-2.0 || { echo "Need: libxfce4panel-2.0" >&2; exit 1; }
pkg-config --exists libxfconf-0 || { echo "Need: libxfconf-0" >&2; exit 1; }
pkg-config --exists gtk+-3.0 || { echo "Need: gtk+-3.0" >&2; exit 1; }
command -v valac >/dev/null 2>&1 || { echo "Need: valac" >&2; exit 1; }

BUILD="${ROOT}/build"
rm -rf "${BUILD}"
meson setup "${BUILD}" \
  --prefix="${PREFIX}" \
  --libdir=lib \
  -Dbuildtype=release

meson compile -C "${BUILD}"
meson install -C "${BUILD}"

# Ensure icon cache
if command -v gtk-update-icon-cache >/dev/null 2>&1; then
  gtk-update-icon-cache -f -t "${DATADIR}/icons/hicolor" 2>/dev/null || true
fi

# Compile translations if msgfmt present
if command -v msgfmt >/dev/null 2>&1 && [ -d "${ROOT}/po" ]; then
  while read -r lang; do
    [ -z "${lang}" ] && continue
    po="${ROOT}/po/${lang}.po"
    [ -f "${po}" ] || continue
    mkdir -p "${LOCALEDIR}/${lang}/LC_MESSAGES"
    msgfmt -o "${LOCALEDIR}/${lang}/LC_MESSAGES/nicecalendar.mo" "${po}" \
      && echo "  locale: ${lang}"
  done < "${ROOT}/po/LINGUAS" 2>/dev/null || true
fi

echo ""
echo "Installed to ${PREFIX}"
echo "Restart the panel:  xfce4-panel -r"
echo "Then: Panel → Add New Items → NiceCalendar"
